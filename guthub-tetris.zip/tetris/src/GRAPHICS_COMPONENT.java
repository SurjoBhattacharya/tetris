import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.Timer;
import java.util.*;
public class GRAPHICS_COMPONENT extends JPanel implements ActionListener, KeyListener {
    static ArrayList<int[][]> arr = new ArrayList<>(), currentSelector =  new ArrayList<>();
    static boolean plop = false,redColor=false;
    static int[][] arr2d = new int[2][2];
    static int blockX = 500,blockY=0;
     Timer t = new Timer(100, this);
    public GRAPHICS_COMPONENT() {
        this.addKeyListener(this);
        this.setFocusTraversalKeysEnabled(true);
        this.setFocusable(true);
       t.start();
    }


    public void paint(Graphics g) {
        super.paint(g);
         int[][] arr2de = {{blockX,blockY},{blockX+50,blockY+50}};
         arr2d = arr2de;
        for(int i = 0; i < arr.size(); i++) {
            for(int j = 0; j < arr.get(i).length; j++) {
                int[][] e = arr.get(i);
                drawRectangle(g,e[j][0],e[j][1],50,50);
            }
        }

        for(int i = 0; i < arr2d.length; i++)  {
           drawRectangle(g, arr2d[i][0],arr2d[i][1],50,50);
        }
    }
    void drawRectangle(Graphics g, int x, int y, int width, int height) {
        g.fillRect(x,y,width,height);
    }
    static void makeNewBlock(int[][] block) {
      arr.add(block);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        blockY+=10;
        for(int[][] i: arr) {
         for(int j = 0; j < i.length; j++) {
              for(int k = 0; k < arr2d.length; k++) {
                 if(new Rectangle(i[j][0],i[j][1],50,50).intersects(new Rectangle(arr2d[k][0],arr2d[k][1],50,50))) plop=true;
             }
         }
        }
        if(blockY >= 500 || plop) {
            int[][] E = arr2d;

            pushBlock(E);
           blockY = 0;
           plop=false;
        }
     repaint();
    }
    void pushBlock(int[][] i) {
        makeNewBlock(i);
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
      switch(e.getKeyChar()) {
          case 'a':
              blockX-=10;
              break;
          case 'd':
              blockX+=10;
              break;
          default:
              break;
      }
    }

    @Override
    public void keyReleased(KeyEvent e) {

    }
}