import javax.swing.*;
import java.awt.event.*;
public class MainGame extends JFrame implements ActionListener{
    Timer t;
    public static boolean sayBlockPlaced = false;
    public MainGame() {
        this.setSize(1000,1000);
        this.setResizable(true);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);
        this.setTitle("bootleg tetris");
        this.add(new GRAPHICS_COMPONENT());
        t = new Timer(70, this);
        t.start();
    }

    public static void main(String[] args) {
        new MainGame();
    }

     @Override
     public void actionPerformed(ActionEvent e) {
         for(int[][] i : GRAPHICS_COMPONENT.arr) {
             for(int[] j: i) {
               for(int k : j) {
                   System.out.println(k);
               }
             }
             if(sayBlockPlaced) {
               System.out.println("a block is placed(hopefully)");
               sayBlockPlaced = false;
             } else {
                 System.out.println();
             }
         }


    }
}

